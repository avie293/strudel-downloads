scoreboard objectives add daycounter dummy
scoreboard players set #ticks_per_day daycounter 24000